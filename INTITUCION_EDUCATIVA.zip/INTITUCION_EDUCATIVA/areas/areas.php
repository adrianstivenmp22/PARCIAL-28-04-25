<?php
include 'conexion.php';

// Agregar Área
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['agregar_area'])) {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];

    $query = "INSERT INTO areas (nombre, descripcion) VALUES (?, ?)";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("ss", $nombre, $descripcion);
    $stmt->execute();

    echo "<p>Área agregada exitosamente.</p>";
}

// Listar Áreas
$query_areas = "SELECT * FROM areas";
$resultado = $conexion->query($query_areas);
?>

<h2>Agregar Área</h2>
<form method="POST" action="">
    <input type="text" name="nombre" placeholder="Nombre del Área" required>
    <textarea name="descripcion" placeholder="Descripción" required></textarea>
    <button type="submit" name="agregar_area">Guardar Área</button>
</form>

<h2>Listado de Áreas</h2>
<table border="1">
    <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Descripción</th>
    </tr>
    <?php while ($area = $resultado->fetch_assoc()) { ?>
    <tr>
        <td><?php echo $area['id']; ?></td>
        <td><?php echo $area['nombre']; ?></td>
        <td><?php echo $area['descripcion']; ?></td>
    </tr>
    <?php } ?>
</table>
