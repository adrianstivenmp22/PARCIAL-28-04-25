<?php
include '../conexion.php';
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../index.php");
    exit();
}

$resultado = $conn->query("SELECT * FROM cursos");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Cursos</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    <h1>Cursos</h1>
    <table border="1">
        <tr><th>ID</th><th>Nombre</th></tr>
        <?php while($fila = $resultado->fetch_assoc()) { ?>
        <tr><td><?= $fila['id'] ?></td><td><?= $fila['nombre'] ?></td></tr>
        <?php } ?>
    </table>
    <a href="../dashboard.php">Volver</a>
</body>
</html>
