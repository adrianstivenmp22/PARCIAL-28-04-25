<?php
session_start();
if (isset($_SESSION['usuario'])) {
    header("Location: dashboard.php");
    exit();
}
?>

<?php
// index.php

// Aquí podrías hacer validaciones o conexiones si quieres
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #7f00ff, #00bfff);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-container {
            background-color: #333;
            padding: 40px;
            border-radius: 10px;
            width: 350px;
            box-shadow: 0px 0px 10px 0px #000;
            text-align: center;
            color: #fff;
        }

        .login-container h2 {
            margin-bottom: 10px;
        }

        .login-container p {
            font-size: 14px;
            margin-bottom: 30px;
            color: #aaa;
        }

        .input-field {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            background: #555;
            border: none;
            border-radius: 5px;
            color: #fff;
        }

        .input-field::placeholder {
            color: #ccc;
        }

        .forgot-password {
            display: block;
            text-align: right;
            margin-bottom: 20px;
            font-size: 12px;
            color: #ccc;
            text-decoration: none;
        }

        .btn-login {
            background-color: transparent;
            border: 1px solid #fff;
            padding: 10px 20px;
            color: #fff;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
            width: 100%;
            margin-bottom: 20px;
        }

        .btn-login:hover {
            background-color: #fff;
            color: #333;
        }

        .social-icons a {
            margin: 0 10px;
            color: #fff;
            text-decoration: none;
            font-size: 18px;
        }

        .signup-link {
            margin-top: 20px;
            font-size: 14px;
        }

        .signup-link a {
            color: #ccc;
            text-decoration: none;
        }

        .signup-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="login-container">
    <h2>LOGIN</h2>
    <p>Por favor ingresa tu correo y contraseña</p>

    <form action="procesar_login.php" method="POST">
        <input type="email" name="correo" class="input-field" placeholder="Correo electrónico" required>
        <input type="password" name="contrasena" class="input-field" placeholder="Contraseña" required>
        
        <a href="#" class="forgot-password">¿Olvidó su contraseña?</a>

        <button type="submit" class="btn-login">Iniciar Sesión</button>
    </form>

    <div class="social-icons">
        <a href="#"><i class="fab fa-facebook-f">F</i></a>
        <a href="#"><i class="fab fa-twitter">T</i></a>
        <a href="#"><i class="fab fa-google">G</i></a>
    </div>

    <div class="signup-link">
        ¿No tienes cuenta? <a href="#">Regístrate</a>
    </div>
</div>

</body>
</html>
