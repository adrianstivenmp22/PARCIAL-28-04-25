<?php
include '../conexion.php';
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../index.php");
    exit();
}

$id = $_GET['id'];
$conn->query("DELETE FROM usuarios WHERE id=$id");
header("Location: listar.php");
?>
