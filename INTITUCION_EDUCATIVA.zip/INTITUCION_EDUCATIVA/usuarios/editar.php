<?php
include '../conexion.php';
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../index.php");
    exit();
}

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM usuarios WHERE id=$id");
$usuario = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $usuarioNew = $_POST['usuario'];
    $clave = $_POST['clave'];

    $conn->query("UPDATE usuarios SET nombre='$nombre', usuario='$usuarioNew', clave='$clave' WHERE id=$id");
    header("Location: listar.php");
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Usuario</title>
</head>
<body>
    <h1>Editar Usuario</h1>
    <form method="POST">
        Nombre: <input type="text" name="nombre" value="<?= $usuario['nombre'] ?>" required><br>
        Usuario: <input type="text" name="usuario" value="<?= $usuario['usuario'] ?>" required><br>
        Clave: <input type="password" name="clave" value="<?= $usuario['clave'] ?>" required><br>
        <button type="submit">Actualizar</button>
    </form>
    <a href="listar.php">Volver</a>
</body>
</html>
