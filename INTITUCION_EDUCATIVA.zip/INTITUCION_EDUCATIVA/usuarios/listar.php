<?php
include '../conexion.php';
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../index.php");
    exit();
}

$resultado = $conn->query("SELECT * FROM usuarios");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Usuarios</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    <h1>Usuarios</h1>
    <a href="agregar.php">Agregar Usuario</a>
    <table border="1">
        <tr>
            <th>ID</th><th>Nombre</th><th>Usuario</th><th>Acciones</th>
        </tr>
        <?php while($fila = $resultado->fetch_assoc()) { ?>
        <tr>
            <td><?= $fila['id'] ?></td>
            <td><?= $fila['nombre'] ?></td>
            <td><?= $fila['usuario'] ?></td>
            <td>
                <a href="editar.php?id=<?= $fila['id'] ?>">Editar</a> | 
                <a href="eliminar.php?id=<?= $fila['id'] ?>" onclick="return confirm('¿Seguro que quieres eliminar?')">Eliminar</a>
            </td>
        </tr>
        <?php } ?>
    </table>
    <a href="../dashboard.php">Volver al Dashboard</a>
</body>
</html>
