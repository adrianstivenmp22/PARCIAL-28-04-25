<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Institución Educativa</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
    <h1>Bienvenido, <?php echo $_SESSION['usuario']; ?>!</h1>

    <nav>
        <ul>
            <li><a href="usuarios/listar.php">Usuarios</a></li>
            <li><a href="cursos/listar.php">Cursos</a></li>
            <li><a href="inscripciones/listar.php">Inscripciones</a></li>
            <li><a href="areas/listar.php">Áreas</a></li>
            <li><a href="equipos/listar.php">Equipos Tecnológicos</a></li>
            <li><a href="notas/listar.php">Notas</a></li>
            <li><a href="eventos/listar.php">Eventos</a></li>
            <li><a href="auditoria/ver_auditoria.php">Auditoría</a></li>
            <li><a href="logout.php">Cerrar Sesión</a></li>
        </ul>
    </nav>
</body>
</html>
