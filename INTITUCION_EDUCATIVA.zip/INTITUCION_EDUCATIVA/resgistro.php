<?php
include 'conexion.php';

$mensaje = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre_usuario = trim($_POST['nombre_usuario']);
    $correo = trim($_POST['correo']);
    $contrasena = password_hash($_POST['contrasena'], PASSWORD_DEFAULT);
    $rol = $_POST['rol'];

    $verificar = $conexion->prepare("SELECT id FROM usuarios WHERE nombre_usuario = ? OR correo = ?");
    $verificar->bind_param("ss", $nombre_usuario, $correo);
    $verificar->execute();
    $verificar->store_result();

    if ($verificar->num_rows > 0) {
        $mensaje = "⚠️ Ya existe un usuario con ese nombre o correo.";
    } else {
        $query = $conexion->prepare("INSERT INTO usuarios (nombre_usuario, correo, contrasena, rol) VALUES (?, ?, ?, ?)");
        $query->bind_param("ssss", $nombre_usuario, $correo, $contrasena, $rol);
        if ($query->execute()) {
            $mensaje = "✅ Registro exitoso.";
        } else {
            $mensaje = "❌ Error al registrar usuario.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro - Institución Educativa</title>
    <link rel="stylesheet" href="estilos.css">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
        }
        body {
            height: 100vh;
            background: #f0f2f5;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            width: 900px;
            height: 600px;
            background: #fff;
            display: flex;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 8px 20px rgba(0,0,0,0.2);
        }
        .container .imagen {
            width: 50%;
            background: url('img/registro.jpg') no-repeat center center/cover;
        }
        .container .formulario {
            width: 50%;
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .formulario h2 {
            margin-bottom: 20px;
            color: #333;
        }
        .formulario input, .formulario select {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 8px;
        }
        .formulario button {
            width: 100%;
            padding: 12px;
            background: #4a90e2;
            border: none;
            color: white;
            font-size: 16px;
            border-radius: 8px;
            margin-top: 15px;
            cursor: pointer;
            transition: background 0.3s;
        }
        .formulario button:hover {
            background: #357ABD;
        }
        .mensaje {
            margin-bottom: 10px;
            font-weight: bold;
            color: #e74c3c;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="imagen"></div>

    <div class="formulario">
        <h2>Crear una cuenta</h2>

        <?php if ($mensaje): ?>
            <div class="mensaje"><?php echo $mensaje; ?></div>
        <?php endif; ?>

        <form method="POST">
            <input type="text" name="nombre_usuario" placeholder="Nombre de usuario" required>
            <input type="email" name="correo" placeholder="Correo electrónico" required>
            <input type="password" name="contrasena" placeholder="Contraseña" required>
            <select name="rol" required>
                <option value="">Seleccione un rol</option>
                <option value="estudiante">Estudiante</option>
                <option value="docente">Docente</option>
            </select>
            <button type="submit">Registrarse</button>
        </form>
    </div>
</div>

</body>
</html>
