<?php
// Conexión a la base de datos
$conexion = new mysqli("localhost", "usuario_db", "contraseña_db", "nombre_db");

if ($conexion->connect_error) {
    die("Error en la conexión: " . $conexion->connect_error);
}

// Recibir datos del formulario
$correo = $_POST['correo'];
$contrasena = $_POST['contrasena'];

// Evitar inyección SQL
$correo = $conexion->real_escape_string($correo);
$contrasena = $conexion->real_escape_string($contrasena);

// Consultar usuario
$sql = "SELECT * FROM usuarios WHERE correo = '$correo' AND contrasena = '$contrasena'";
$resultado = $conexion->query($sql);

if ($resultado->num_rows > 0) {
    session_start();
    $_SESSION['correo'] = $correo;
    header("Location: dashboard.php"); // Redirigir al dashboard o página principal
} else {
    echo "<script>alert('Correo o contraseña incorrectos'); window.location.href='login.html';</script>";
}

$conexion->close();
?>
