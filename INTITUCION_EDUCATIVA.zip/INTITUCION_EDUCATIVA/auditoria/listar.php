<?php
include '../conexion.php';
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../index.php");
    exit();
}

$resultado = $conn->query("SELECT * FROM auditoria");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Auditoría</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    <h1>Registro de Auditoría</h1>
    <table border="1">
        <tr><th>ID</th><th>Acción</th><th>Fecha</th><th>Usuario</th></tr>
        <?php while($fila = $resultado->fetch_assoc()) { ?>
        <tr><td><?= $fila['id'] ?></td><td><?= $fila['accion'] ?></td><td><?= $fila['fecha'] ?></td><td><?= $fila['usuario'] ?></td></tr>
        <?php } ?>
    </table>
    <a href="../dashboard.php">Volver</a>
</body>
</html>
