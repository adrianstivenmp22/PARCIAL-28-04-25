<?php
include '../conexion.php';
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../index.php");
    exit();
}

$resultado = $conn->query("SELECT * FROM notas");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Notas</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    <h1>Notas de Estudiantes</h1>
    <table border="1">
        <tr><th>ID</th><th>Estudiante</th><th>Área</th><th>Nota</th></tr>
        <?php while($fila = $resultado->fetch_assoc()) { ?>
        <tr><td><?= $fila['id'] ?></td><td><?= $fila['estudiante'] ?></td><td><?= $fila['area'] ?></td><td><?= $fila['nota'] ?></td></tr>
        <?php } ?>
    </table>
    <a href="../dashboard.php">Volver</a>
</body>
</html>
