<?php
include 'conexion.php';

// Obtener estudiantes
$query_estudiantes = "SELECT id, nombre FROM estudiantes";
$estudiantes = $conexion->query($query_estudiantes);

// Obtener cursos
$query_cursos = "SELECT id, nombre FROM cursos";
$cursos = $conexion->query($query_cursos);

// Guardar inscripción
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['guardar_inscripcion'])) {
    $id_estudiante = $_POST['id_estudiante'];
    $id_curso = $_POST['id_curso'];
    $fecha_inscripcion = date('Y-m-d');
    $estado = 'activo';

    $query = "INSERT INTO inscripciones (id_estudiante, id_curso, fecha_inscripcion, estado) VALUES (?, ?, ?, ?)";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("iiss", $id_estudiante, $id_curso, $fecha_inscripcion, $estado);
    $stmt->execute();

    echo "<p>Inscripción realizada correctamente.</p>";
}
?>

<h2>Inscribir Estudiante a Curso</h2>
<form method="POST" action="">
    <label>Estudiante:</label>
    <select name="id_estudiante" required>
        <?php while ($row = $estudiantes->fetch_assoc()) { ?>
            <option value="<?php echo $row['id']; ?>"><?php echo $row['nombre']; ?></option>
        <?php } ?>
    </select><br><br>

    <label>Curso:</label>
    <select name="id_curso" required>
        <?php while ($row = $cursos->fetch_assoc()) { ?>
            <option value="<?php echo $row['id']; ?>"><?php echo $row['nombre']; ?></option>
        <?php } ?>
    </select><br><br>

    <button type="submit" name="guardar_inscripcion">Inscribir</button>
</form>
